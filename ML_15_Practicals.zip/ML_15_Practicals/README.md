# Machine Learning Practicals (15)

Simple Jupyter Notebook implementations for introductory Machine Learning lab practicals.

## Practicals
1. `01_numpy_pandas_matplotlib.ipynb` — NumPy, Pandas and Matplotlib for Data Analysis and Visualization
2. `02_complete_ml_workflow.ipynb` — Complete Machine Learning Workflow with scikit-learn
3. `03_bias_variance_polynomial_regression.ipynb` — Study Bias, Variance, Overfitting and Underfitting with Polynomial Regression
4. `04_simple_linear_regression.ipynb` — Simple Linear Regression and Error Evaluation
5. `05_multiple_linear_regression.ipynb` — Multiple Linear Regression with MAE, MSE, RMSE and R-squared
6. `06_regularization_ridge_lasso_elasticnet.ipynb` — Compare Ridge, Lasso and Elastic Net Regression
7. `07_logistic_regression.ipynb` — Logistic Regression for Binary Classification
8. `08_knn_classification.ipynb` — K-Nearest Neighbours and Effect of K on Accuracy
9. `09_decision_tree_depth.ipynb` — Decision Tree Classifier and Effect of Tree Depth
10. `10_random_forest_vs_decision_tree.ipynb` — Compare Random Forest and Decision Tree
11. `11_kmeans_elbow.ipynb` — K-Means Clustering and Elbow Method
12. `12_hierarchical_clustering.ipynb` — Agglomerative Hierarchical Clustering and Dendrogram
13. `13_dbscan_outlier_detection.ipynb` — DBSCAN Clustering and Outlier Detection
14. `14_pca_dimensionality_reduction.ipynb` — PCA Dimensionality Reduction and Variance Preservation
15. `15_grid_search_cross_validation.ipynb` — Hyperparameter Tuning using Grid Search and Cross-Validation

## Setup
Recommended: Python 3.10+.

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
python -m pip install --upgrade pip
pip install numpy pandas matplotlib scikit-learn scipy jupyter
jupyter notebook
```

Open the notebook you want and run cells from top to bottom.

## Notes
- Most notebooks use datasets built into scikit-learn or generated sample data.
- Practical 5 fetches California Housing data and needs internet access on first run.
- Results can vary with library versions and data splits.
- These notebooks are learning examples, not production-ready pipelines.
